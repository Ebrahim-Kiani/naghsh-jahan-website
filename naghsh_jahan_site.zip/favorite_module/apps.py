from django.apps import AppConfig


class FavoriteModuleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'favorite_module'
